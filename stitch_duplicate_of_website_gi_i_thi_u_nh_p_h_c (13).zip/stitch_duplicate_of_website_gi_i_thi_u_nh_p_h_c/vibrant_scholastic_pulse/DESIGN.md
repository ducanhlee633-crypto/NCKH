---
name: Vibrant Scholastic Pulse
colors:
  surface: '#f7f9fd'
  surface-dim: '#d8dade'
  surface-bright: '#f7f9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f8'
  surface-container: '#eceef2'
  surface-container-high: '#e6e8ec'
  surface-container-highest: '#e0e3e6'
  on-surface: '#181c1f'
  on-surface-variant: '#444656'
  inverse-surface: '#2d3134'
  inverse-on-surface: '#eff1f5'
  outline: '#757688'
  outline-variant: '#c5c5d9'
  surface-tint: '#3245f1'
  primary: '#0019c6'
  on-primary: '#ffffff'
  primary-container: '#2538e8'
  on-primary-container: '#c1c6ff'
  inverse-primary: '#bdc2ff'
  secondary: '#00696e'
  on-secondary: '#ffffff'
  secondary-container: '#61f4fd'
  on-secondary-container: '#006e73'
  tertiary: '#7c1500'
  on-tertiary: '#ffffff'
  tertiary-container: '#a1280c'
  on-tertiary-container: '#ffbaaa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe0ff'
  primary-fixed-dim: '#bdc2ff'
  on-primary-fixed: '#000866'
  on-primary-fixed-variant: '#0721db'
  secondary-fixed: '#6bf6ff'
  secondary-fixed-dim: '#3edae3'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f53'
  tertiary-fixed: '#ffdad2'
  tertiary-fixed-dim: '#ffb4a3'
  on-tertiary-fixed: '#3d0600'
  on-tertiary-fixed-variant: '#8c1900'
  background: '#f7f9fd'
  on-background: '#181c1f'
  surface-variant: '#e0e3e6'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: 4rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an energetic, uplifting, and frictionless learning environment centered on cadence, flow, and personal momentum. Designed for students, lifelong learners, and modern educators, the interface creates an encouraging, focused digital campus where academic rigor meets lively momentum.

The design movement blends **Modern Dynamic Clean** with **Tactile Glass-Toned Softness**:
- **Tone & Mood:** Encouraging, rhythmic, clear, and intellectually stimulating. It rejects cold, clinical LMS aesthetics in favor of cheerful clarity and momentum.
- **Visual Personality:** Airy surfaces, rich royal blue structures, luminous cyan momentum cues, and warm coral celebratory accents that reward study streaks and progress.
- **Execution Style:** Crisp, balanced negative space paired with curved container tiers, high-readability typography, pill-shaped micro-interactions, and translucent badge treatments.

## Colors

The palette establishes an immediate sense of focus, rhythmic pacing, and friendly motivation.

- **Primary (`#2538E8` - Royal Indigo):** Anchors foundational UI elements, high-emphasis action triggers, active navigation items, and primary typography. Inspires confidence and mental alertness.
- **Secondary (`#00C2CB` - Pulse Teal/Cyan):** Communicates active cadence, completed milestones, progress rings, and continuous study momentum.
- **Tertiary (`#FF6B4A` - Coral Radiance):** Reserved for celebration, current streaks, urgent reminders, gamification badges, and high-impact micro-delights.
- **Neutral Canvas (`#F7F9FD` - Glacial Off-White):** A soft, low-strain cool white foundation that lets vibrant educational cards float effortlessly.
- **Surface Elevation (`#FFFFFF`):** High-clarity white for cards, sheets, and interactive modules.
- **Text & Structure (`#101736`):** Deep indigo-tinted slate for body copy and headings, replacing dead black with harmonic depth.

## Typography

The typographic system utilizes **Plus Jakarta Sans** for prominent identity, headings, and long-form study modules to convey modern warmth and approachable geometric friendliness. **Inter** handles utility-driven roles: metadata, status chips, progress statistics, and form controls where maximum legibility and tracking precision are essential.

- **Scale Rhythm:** Headings feature tightened tracking to maintain cohesion across multilingual and tonal text structures.
- **Hierarchy:** Bold weights are leveraged for milestone counters and module titles, while regular weights in generous line heights prioritize effortless sustained reading during long study sessions.

## Layout & Spacing

The layout is built on an adaptive 12-column grid prioritizing breathability and fluid containment.

- **Desktop (1200px+):** 12-column fluid grid, 2rem gutters, 3rem screen margins. Side navigation and contextual study widgets dock alongside a centered learning stream (max content width 1280px).
- **Tablet (768px - 1199px):** 8-column grid with 1.5rem gutters and 1.5rem margins. Collapses multi-pane dashboards into sticky horizontal rail sections or stacked study cards.
- **Mobile (320px - 767px):** 4-column structure with 1rem gutters and 1rem safe outer margins. Touch-friendly vertical scrolls with continuous card carousels for topic navigation.
- **Spacing Cadence:** Internal cards leverage `space-lg` (24px) for padding to ensure content feels open, never cramped. Micro elements align strictly to a 4px sub-grid via `space-xs` and `space-sm`.

## Elevation & Depth

Visual depth is achieved through **ambient indigo-tinted drop shadows** paired with soft, low-contrast structural borders:

- **Surface Base (Level 0):** Pure `#F7F9FD` background; flat, serene, glare-free.
- **Resting Cards (Level 1):** `#FFFFFF` surfaces with a fine border (`rgba(37, 56, 232, 0.06)`) and an ultra-diffused shadow: `0px 4px 20px -2px rgba(16, 23, 54, 0.04)`.
- **Hover & Active Study Modules (Level 2):** Shift upward by 2px with an enhanced shadow: `0px 12px 28px -4px rgba(37, 56, 232, 0.10)`.
- **Modals, Floating Study Timers & Overlays (Level 3):** Frosted ambient backdrop blur (`backdrop-filter: blur(12px)`) with layered elevation: `0px 24px 48px -8px rgba(16, 23, 54, 0.16)`.
- **Glow Accents:** Key celebratory triggers or streak milestones project a subtle colored aura: `0px 0px 20px rgba(255, 107, 74, 0.28)`.

## Shapes

The design system employs a **Rounded** shape language (`roundedness: 2` / 0.5rem base) to maintain an approachable, friendly visual presence while preserving structural neatness for educational tables and lesson outlines.

- **Standard Cards & Containers:** `rounded-lg` (1rem / 16px) for curriculum blocks, quiz containers, and user profiles.
- **Interactive Modals & Feature Banners:** `rounded-xl` (1.5rem / 24px) for milestone summaries and course hero cards.
- **Chips, Badges & Micro-controls:** Fully rounded pill curves (`9999px`) for progress indicators, tags, difficulty badges, and segmented filters.
- **Form Controls:** 0.75rem (12px) corner radii, striking a balance between structure and welcoming warmth.

## Components

### Buttons
- **Primary:** Royal Indigo background, white text, pill or `rounded-lg` silhouette, subtle scale down (`0.98`) on tap, with a soft indigo glow upon focus.
- **Secondary:** Transparent fill with a 1.5px solid border in Primary Indigo or Teal, shifting to an 8% primary wash on hover.
- **Tertiary Accent (Streak / Action):** Vibrant Coral fill, white bold label, utilized for "Start Quiz", "Claim XP", or streak checkpoints.

### Chips & Pill Badges
- **Status & Subject Tags:** Rounded pill shape (`rounded-full`), `space-xs` vertical and `space-sm` horizontal padding.
- **Color Logic:** Tinted semi-transparent backgrounds (10% opacity) matching their respective status text (e.g., Cyan background with deep teal text for "In Progress"; Coral background with rich rust text for "7-Day Streak").

### Cards
- **Course & Lesson Cards:** Clean `#FFFFFF` fill, `rounded-lg`, 1px subtle tinted border (`#E4E9F7`). Features progress bars anchored directly to the bottom border with smooth secondary teal fills.
- **Interactive Quiz Cards:** High contrast, shifting to an active Cyan-Indigo perimeter ring upon selection.

### Form Inputs & Search
- Generous 48px standard touch targets, off-white background (`#FFFFFF`), neutral border (`#D8E0F0`) shifting to a 2px Royal Indigo border with a soft cyan focus ring (`0 0 0 3px rgba(0, 194, 203, 0.2)`). Clear helper icons positioned inside the left edge.

### Checkboxes & Radio Buttons
- 20px smoothly rounded boxes (checkbox: 6px radius, radio: circular) in 1.5px slate borders. Checked state triggers an energetic Royal Indigo fill with an animated white check/dot icon.

### Study-Specific Components
- **Pulse Streak Tracker:** Pill-shaped module combining the coral flame icon, dynamic day ticks, and animated counter text.
- **Progress Rhythm Gauge:** Thin circular and linear SVG progress bars combining gradient sweeps from Royal Indigo to Vibrant Cyan.
- **Flashcard Modules:** Flippable 3D surface with clean centered typographic hierarchy and gentle tactile depth.